namespace Projeto_Cadastro_de_Series
{
    public abstract class EntidadeBase
    {
        public int Id {get; protected set; }
    }
}