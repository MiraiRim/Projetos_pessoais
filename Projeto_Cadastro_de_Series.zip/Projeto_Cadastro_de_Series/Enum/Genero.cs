namespace Projeto_Cadastro_de_Series
{
        public enum Genero
        {
                Aventura = 1,
                Cinema_de_arte = 2,
                Chanchada = 3,
                Comedia = 4,
                Comedia_de_acao = 5,
                Comedia_de_terror = 6,
                Comedia_dramática = 7,
                Comedia_romântica = 8,
                Danca = 9,
                Documentario = 10,
                Docuficcao = 11,
                Drama = 12,
                Espionagem = 13,
                Faroeste = 14,
                Fantasia = 15,
                Fantasia_cientifica = 16,
                Ficcao_cientifica = 17,
                Filmes_com_truques = 18,
                Filmes_de_guerra = 19,
                Misterio = 20,
                Musical = 21,
                Filme_policial = 22,
                Romance =23,
                Terror = 24,
                Thriller = 25
        }
}